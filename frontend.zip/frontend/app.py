# app.py
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import streamlit as st
import pandas as pd
from src.recommender import ContentBasedRecommender

# --- Page Configuration ---
st.set_page_config(
    page_title="Movie Recommender",
    page_icon="🎬",
    layout="centered"
)

# --- Caching the Recommender ---
@st.cache_resource
def load_recommender():
    """
    Load the ContentBasedRecommender instance.
    Using st.cache_resource ensures the model is loaded only once.
    """
    print("Loading recommender model for the first time...")
    recommender = ContentBasedRecommender(movies_filepath=r'C:\Users\91994\Documents\movie_recommender\movie_recommender\data\movies.csv')
    return recommender

# --- Main Application ---
st.title("🎬 Content-Based Movie Recommender")

st.markdown("""
Welcome! This app recommends movies based on their genres.
Select a movie from the dropdown list below and click the "Recommend" button to get started.
""")

# Load the model
recommender = load_recommender()

# Get the list of movie titles for the dropdown
movie_list = recommender.movies_df['title'].sort_values().tolist()

# Create the user interface components
selected_movie = st.selectbox(
    "Select a movie you like:",
    options=movie_list
)

if st.button("Recommend"):
    if selected_movie:
        with st.spinner('Finding recommendations for you...'):
            # Get recommendations
            recommendations_df = recommender.recommend(selected_movie, n_recommendations=10)

            if not recommendations_df.empty:
                st.subheader(f"Because you liked '{selected_movie}', you might also enjoy:")

                # Reformat genres for display
                recommendations_df['genres'] = recommendations_df['genres'].str.replace(' ', ', ')
                
                # Display the recommendations in a table, without the index
                st.dataframe(
                    recommendations_df,
                    hide_index=True,
                    use_container_width=True
                )
            else:
                st.error(f"Could not find recommendations for '{selected_movie}'. It might not be in our dataset.")
    else:
        st.warning("Please select a movie.")