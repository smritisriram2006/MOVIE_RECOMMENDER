# src/recommender.py

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class ContentBasedRecommender:
    """
    A content-based movie recommender system based on movie genres.
    """
    def __init__(self, movies_filepath):
        """
        Initializes the recommender by loading and preparing the movie data.

        Args:
            movies_filepath (str): The path to the movies.csv file.
        """
        self.movies_df = None
        self.tfidf_matrix = None
        self.cosine_sim = None
        self.movie_indices = None
        self._prepare_model(movies_filepath)

    def _prepare_model(self, movies_filepath):
        """
        Loads data, processes it, and computes the similarity matrix.
        This is a private helper method called by __init__.
        """
        # --- 1. Load Data ---
        print("Loading and preparing data...")
        self.movies_df = pd.read_csv(movies_filepath)

        # --- 2. Feature Extraction (TF-IDF) ---
        # Replace '|' with a space in the genres string to treat genres as separate words.
        # Handle missing genres by filling NaN with an empty string.
        self.movies_df['genres'] = self.movies_df['genres'].str.replace('|', ' ', regex=False).fillna('')

        # Create a TfidfVectorizer object.
        # stop_words='english' removes common English words that don't add much meaning.
        tfidf = TfidfVectorizer(stop_words='english')
        
        # Fit and transform the data to create the TF-IDF matrix.
        self.tfidf_matrix = tfidf.fit_transform(self.movies_df['genres'])

        # --- 3. Compute Cosine Similarity ---
        # This creates a matrix where cell (i, j) is the similarity score between movie i and movie j.
        self.cosine_sim = cosine_similarity(self.tfidf_matrix, self.tfidf_matrix)
        
        # --- 4. Create a mapping from movie titles to their index ---
        # This will allow us to easily find a movie's index from its title.
        self.movie_indices = pd.Series(self.movies_df.index, index=self.movies_df['title']).drop_duplicates()
        print("Model preparation complete!")


    def recommend(self, movie_title, n_recommendations=10):
        """
        Recommends movies similar to a given movie title.

        Args:
            movie_title (str): The title of the movie to get recommendations for.
            n_recommendations (int): The number of recommendations to return.

        Returns:
            pandas.DataFrame: A DataFrame containing the recommended movie titles and their genres.
                              Returns an empty DataFrame if the movie title is not found.
        """
        # Check if the movie title exists in our dataset
        if movie_title not in self.movie_indices:
            print(f"Error: Movie '{movie_title}' not found in the dataset.")
            return pd.DataFrame()

        # Get the index of the movie that matches the title
        idx = self.movie_indices[movie_title]

        # Get the pairwise similarity scores of all movies with that movie
        # The result is a list of tuples (movie_index, similarity_score)
        sim_scores = list(enumerate(self.cosine_sim[idx]))

        # Sort the movies based on the similarity scores in descending order
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

        # Get the scores of the n_recommendations most similar movies.
        # We start from index 1 to skip the first movie, which is the input movie itself (similarity=1.0)
        sim_scores = sim_scores[1:n_recommendations + 1]

        # Get the movie indices from the sorted scores
        movie_indices = [i[0] for i in sim_scores]

        # Return the top n_recommendations most similar movies
        return self.movies_df[['title', 'genres']].iloc[movie_indices].assign(
            genres=lambda df: df['genres'].str.replace(' ', '|'))