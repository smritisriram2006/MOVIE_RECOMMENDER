# src/utils.py

import pandas as pd

def display_recommendations(recommendations_df: pd.DataFrame, original_title: str):
    """
    Displays movie recommendations in a user-friendly format in the console.

    Args:
        recommendations_df (pd.DataFrame): DataFrame containing recommended movies.
                                           Expected columns are 'title' and 'genres'.
        original_title (str): The title of the movie the user asked about.
    """
    # Check if the recommendations DataFrame is empty. This happens if the
    # original movie title was not found by the recommender.
    if recommendations_df.empty:
        # We don't need to print an error here because the recommender class already does.
        # This function's job is just to format the output.
        return

    # Print a clear header for the recommendations
    print("\n" + "="*60)
    print(f"Since you liked '{original_title}', you might also like:")
    print("="*60 + "\n")

    # Reformat the genres column for better readability before printing
    recommendations_df['genres'] = recommendations_df['genres'].str.replace(' ', ', ')
    
    # Print the DataFrame without the index for a cleaner look
    print(recommendations_df.to_string(index=False))

    print("\n" + "="*60 + "\n")